let meetings = [], selectedId = null;
const $ = id => document.getElementById(id);
const dt = iso => {try{return new Date(iso).toLocaleString('tr-TR');}catch{return iso;}};
const clean = v => String(v || '');
function node(tag, text, cls) {const e=document.createElement(tag); if(cls)e.className=cls; e.textContent=clean(text); return e;}
async function load() {
  const data=await chrome.storage.local.get(null);
  meetings=Object.entries(data).filter(([k,v])=>k.startsWith('tta_meeting_') && v?.entries?.length).map(([,v])=>v).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
  if(selectedId && !meetings.some(x=>x.id===selectedId)) selectedId=null;
  renderList();renderDetail();
}
function renderList() {
  const q=$('search').value.toLocaleLowerCase('tr-TR'), container=$('meetings');container.replaceChildren();
  for(const m of meetings.filter(m=>[m.title,...m.entries.flatMap(e=>[e.speaker,e.original,e.explanation,...(e.replies||[]).flatMap(r=>[r.en,r.tr])])].join(' ').toLocaleLowerCase('tr-TR').includes(q))){
    const btn=node('button',m.title,'meeting'+(selectedId===m.id?' active':''));
    btn.append(node('small',`${dt(m.startedAt)} · ${m.language==='tr'?'Türkçe döküm':'İngilizce + AI'} · ${m.entries.length} bölüm`));btn.onclick=()=>{selectedId=m.id;renderList();renderDetail();};container.append(btn);
  }
  if(!container.children.length)container.append(node('p','Kayıt bulunamadı.'));
}
function renderDetail(){
  const m=meetings.find(x=>x.id===selectedId);
  $('empty').hidden=!!m;$('detail').hidden=!m;if(!m)return;
  $('title').value=m.title; $('meta').textContent=`Başlangıç: ${dt(m.startedAt)} · Son kayıt: ${dt(m.updatedAt)} · ${m.entries.length} konuşma bölümü`;
  const q=$('filter').value.toLocaleLowerCase('tr-TR'), container=$('entries');container.replaceChildren();
  for(const e of m.entries.filter(e=>[e.speaker,e.original,e.explanation,...(e.replies||[]).flatMap(r=>[r.en,r.tr])].join(' ').toLocaleLowerCase('tr-TR').includes(q))){
    const card=document.createElement('article');card.className='entry';
    card.append(node('div',`${dt(e.at)} · ${e.speaker}`,'who'),node('div',(m.language==='tr'?'TR: ':'EN: ')+e.original,'original'));
    if(m.language!=='tr') card.append(node('div',e.explanation ? 'TR: '+e.explanation : e.error ? 'Açıklama hatası: '+e.error : 'Türkçe açıklama henüz kaydedilmedi.',e.error?'error':'turkish'));
    if(m.language!=='tr' && Array.isArray(e.replies) && e.replies.length){
      const details=document.createElement('details');details.className='reply-list';
      details.append(node('summary',`Cevap önerileri (${e.replies.length})`));
      for(const r of e.replies){
        const rp=node('div',`${r.style}: ${r.en} — ${r.tr}`,'reply');details.append(rp);
      }
      card.append(details);
    }
    container.append(card);
  }
  if(!container.children.length)container.append(node('p','Eşleşen metin bulunamadı.'));
}
function download(content,ext,mime){const blob=new Blob([content],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='teams-'+selectedId+'.'+ext;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);}
$('search').addEventListener('input',renderList);$('filter').addEventListener('input',renderDetail);
$('rename').onclick=async()=>{const m=meetings.find(x=>x.id===selectedId);if(!m)return;m.title=$('title').value.trim().slice(0,160)||m.title;await chrome.storage.local.set({['tta_meeting_'+m.id]:m});renderList();};
$('txt').onclick=()=>{const m=meetings.find(x=>x.id===selectedId);if(!m)return;download([m.title,'Başlangıç: '+dt(m.startedAt),'',...m.entries.flatMap(e=>[`${dt(e.at)} — ${e.speaker}`,`${m.language==='tr'?'TR':'EN'}: ${e.original}`,...(m.language==='tr'?[]:[`TR: ${e.explanation || '(açıklama yok)'}`]),...(e.replies||[]).map(r=>`${r.style}: ${r.en} | ${r.tr}`),''])].join('\n'),'txt','text/plain;charset=utf-8');};
$('json').onclick=()=>{const m=meetings.find(x=>x.id===selectedId);if(m)download(JSON.stringify(m,null,2),'json','application/json');};
$('delete').onclick=async()=>{if(!selectedId||!confirm('Bu toplantı kaydı kalıcı olarak silinsin mi?'))return;await chrome.storage.local.remove('tta_meeting_'+selectedId);selectedId=null;await load();};
load();
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local' && Object.keys(changes).some(k=>k.startsWith('tta_meeting_')))load();});
