(async()=>{
  const settings = await chrome.storage.local.get({apiKey:'',model:'gpt-4.1-mini',showReplies:true,meetingLanguage:'en'});
  const $ = id=>document.getElementById(id);
  $('key').value=settings.apiKey;
  $('model').value=settings.model;
  $('showReplies').checked=settings.showReplies!==false;
  $('language').value=settings.meetingLanguage==='tr'?'tr':'en';
  const reflect=()=>{$('apiSettings').hidden=$('language').value==='tr';};
  $('language').addEventListener('change',reflect);reflect();
  $('history').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('archive.html')});
  $('save').onclick=async()=>{
    const meetingLanguage=$('language').value;
    const apiKey=$('key').value.trim();
    const model=$('model').value.trim()||'gpt-4.1-mini';
    if(meetingLanguage==='en'&&!apiKey){$('status').textContent='İngilizce toplantı için API anahtarı gerekli.';return;}
    await chrome.storage.local.set({meetingLanguage,apiKey,model,showReplies:$('showReplies').checked});
    $('status').textContent=meetingLanguage==='tr'?'Türkçe döküm modu kaydedildi. Teams sekmesinde otomatik uygulanır.':'İngilizce modu kaydedildi. Teams sekmesinde otomatik uygulanır.';
  };
})();
