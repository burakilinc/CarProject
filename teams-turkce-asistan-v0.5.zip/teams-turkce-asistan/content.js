(() => {
  if (window.__teamsTurkceAsistanLoaded) return;
  window.__teamsTurkceAsistanLoaded = true;

  // Every page load starts a new local meeting. Reloading a meeting creates a new archive record.
  let meetingId = crypto.randomUUID();
  let archiveEnabled = true;
  let showReplies = true;
  let meetingLanguage = 'en';
  let settingsReady = false;
  const languageName = () => meetingLanguage === 'tr' ? 'Türkçe' : 'İngilizce';
  chrome.storage.local.get({showReplies:true,meetingLanguage:'en'}).then(x=>{
    showReplies=x.showReplies!==false;
    meetingLanguage=x.meetingLanguage==='tr'?'tr':'en';
    settingsReady=true;
    updateLanguageUI();
  }).catch(()=>{settingsReady=true;updateLanguageUI();});
  chrome.storage.onChanged.addListener((changes, area)=>{
    if(area!=='local')return;
    if(changes.showReplies)showReplies=changes.showReplies.newValue!==false;
    if(changes.meetingLanguage){
      const next=changes.meetingLanguage.newValue==='tr'?'tr':'en';
      if(next!==meetingLanguage){
        // Avoid mixing different languages in a single archived meeting.
        pending=[];seen.clear();meetingId=crypto.randomUUID();
        chrome.runtime.sendMessage({type:'CLEAR_CONTEXT'}).catch(()=>{});
        meetingLanguage=next;
      }
      updateLanguageUI();
    }
  });
  const archiveTime = () => new Date().toISOString();
  async function archive(entry, archiveMeetingId=meetingId, archiveLanguage=meetingLanguage) {
    if (!archiveEnabled) return;
    try {
      const result = await chrome.runtime.sendMessage({type:'ARCHIVE_UPSERT', meetingId:archiveMeetingId, language:archiveLanguage, title:document.title || 'Teams Toplantısı', entry});
      if (result?.error) throw new Error(result.error);
    } catch (e) {status.textContent = 'Arşiv kaydı başarısız: ' + (e.message || e);}
  }
  const root = document.createElement('section');
  root.id = 'tta-root';
  root.innerHTML = `<div class="tta-top"><span class="tta-title">🇹🇷 Teams Türkçe Asistan</span><button id="tta-toggle" title="Küçült">−</button><button id="tta-new" title="Yeni toplantı kaydı başlat">Yeni kayıt</button><button id="tta-history" title="Kaydedilen toplantıları aç">Geçmiş</button><button id="tta-pause">Duraklat</button></div><div class="tta-status" id="tta-status">Altyazılar bekleniyor…</div><div class="tta-list" id="tta-list"><div class="tta-item">Teams toplantısında canlı altyazıları seçtiğin dilde aç. Konuşmacı ve döküm burada görünecek.</div></div><div class="tta-bottom">Metinler bu tarayıcıda otomatik saklanır. Geçmiş: kayıtları ara ve dışa aktar.</div>`;
  document.documentElement.append(root);
  const $ = id => root.querySelector('#' + id);
  const list = $('tta-list'), status = $('tta-status');
  function updateLanguageUI(){
    if(!status)return;
    const tr=meetingLanguage==='tr';
    root.querySelector('.tta-title').textContent=tr?'📝 Teams Döküm Asistanı':'🇹🇷 Teams Türkçe Asistan';
    root.querySelector('.tta-bottom').textContent=tr?'Türkçe konuşma dökümü yerel olarak kaydedilir. API kullanılmaz. Geçmişten TXT/JSON indirebilirsin.':'İngilizce altyazılar açıklanır ve kaydedilir. Geçmişten TXT/JSON indirebilirsin.';
    status.textContent=`${languageName()} modu • Canlı altyazılar bekleniyor…`;
  }
  let paused = false, processing = false, pending = [], lastFlush = 0;
  const seen = new Map();
  const normalize = s => (s || '').replace(/\s+/g, ' ').trim();
  const captionSelectors = [
    '[data-tid="closed-caption-text"]', '[data-tid*="closed-caption"]',
    '[data-tid*="live-caption"]', '[data-testid*="caption"]',
    '[class*="captions-container"] [dir="auto"]', '[class*="caption-text"]'
  ];
  const speakerSelectors = [
    '[data-tid*="speaker-name"]', '[data-tid*="speakerName"]',
    '[data-tid*="caption-name"]', '[data-testid*="speaker-name"]',
    '[class*="speakerName"]', '[class*="speaker-name"]',
    '[class*="caption-speaker"]', '[class*="captionSpeaker"]',
    '[class*="captions-name"]', '[class*="participant-name"]'
  ];
  const discard = /^(turn on|turn off|live captions|caption settings|spoken language|translate to|captions|altyazı|translation language)$/i;
  const validName = value => {
    const n = normalize(value).replace(/:\s*$/, '');
    return n && n.length <= 90 && !discard.test(n) && !/\n/.test(n) && !/[.!?]$/.test(n) ? n : null;
  };
  function speakerFromNode(node) {
    // Inspect only close ancestors: caption containers are commonly speaker+text siblings.
    // Never infer a speaker from participant lists, chat, or unrelated page content.
    let parent = node.parentElement;
    for (let depth = 0; parent && depth < 4; depth++, parent = parent.parentElement) {
      if (root.contains(parent)) break;
      if ((parent.innerText || '').length > 1100) break;
      for (const el of parent.querySelectorAll(speakerSelectors.join(','))) {
        if (el === node || node.contains(el) || el.closest('#tta-root')) continue;
        const name = validName(el.innerText || el.textContent);
        if (name) return name;
      }
      // Some Teams versions render: "Jane Doe: caption text" in one element.
      const combined = normalize(node.innerText || node.textContent);
      const match = combined.match(/^([^:]{2,70}):\s+(.{8,})$/);
      if (match && validName(match[1])) return validName(match[1]);
    }
    return null;
  }
  function stripInlineName(value, speaker) {
    if (!speaker) return value;
    const prefix = `${speaker}:`;
    return value.startsWith(prefix) ? normalize(value.slice(prefix.length)) : value;
  }
  function makeItem(speaker, source, output, error=false, replies=[], language=meetingLanguage) {
    if (list.firstElementChild?.textContent?.startsWith('Teams toplantısında')) list.replaceChildren();
    const item = document.createElement('div'); item.className = 'tta-item';
    const name = document.createElement('div'); name.className = 'tta-speaker';
    name.textContent = speaker || 'Konuşmacı bilinmiyor';
    const original = document.createElement('div'); original.className = 'tta-source'; original.textContent = `${language==='tr'?'TR':'EN'}: ${source}`;
    const translated = document.createElement('div'); translated.className = error ? 'tta-error' : 'tta-translation'; translated.textContent = output;
    item.append(name, original);
    if (output || error) item.append(translated);
    if (!error && Array.isArray(replies) && replies.length) {
      const details = document.createElement('details'); details.className='tta-replies'; details.open=showReplies;
      const summary=document.createElement('summary'); summary.textContent=`💬 Cevap önerileri (${replies.length})`;details.append(summary);
      for (const reply of replies) {
        const card=document.createElement('div');card.className='tta-reply';
        const header=document.createElement('div');header.className='tta-reply-head';
        const style=document.createElement('strong');style.textContent=reply.style;
        const copy=document.createElement('button');copy.type='button';copy.textContent='Kopyala';
        copy.addEventListener('click',async()=>{
          try{await navigator.clipboard.writeText(reply.en); copy.textContent='Kopyalandı';setTimeout(()=>copy.textContent='Kopyala',1300);}
          catch {copy.textContent='Kopyalanamadı';}
        });
        header.append(style,copy);
        const en=document.createElement('div');en.className='tta-reply-en';en.textContent=reply.en;
        const tr=document.createElement('div');tr.className='tta-reply-tr';tr.textContent=reply.tr;
        card.append(header,en,tr);details.append(card);
      }
      item.append(details);
    }
    list.append(item);
    while (list.children.length > 18) list.firstElementChild.remove();
    list.scrollTop = list.scrollHeight;
  }
  function collect() {
    if (paused || !settingsReady) return;
    const nodes = document.querySelectorAll(captionSelectors.join(','));
    for (const node of nodes) {
      if (root.contains(node) || node.closest('#tta-root')) continue;
      if (node.querySelector('[data-tid="closed-caption-text"]')) continue;
      if (node.getClientRects().length === 0) continue;
      let value = normalize(node.innerText || node.textContent);
      const speaker = speakerFromNode(node);
      value = stripInlineName(value, speaker);
      if (value.length < 8 || value.length > 700 || discard.test(value)) continue;
      const old = seen.get(node);
      if (!old || old.value !== value || old.speaker !== speaker) {
        seen.set(node, {value, speaker, changed:Date.now(), sent: old?.speaker === speaker ? (old?.sent || '') : ''});
        continue;
      }
      if (old.sent === value || Date.now() - old.changed < 900) continue;
      if (old.sent && value.startsWith(old.sent)) value = normalize(value.slice(old.sent.length));
      if (value.length < 8) { old.sent = old.value; continue; }
      old.sent = old.value;
      if (pending.some(x => x.text === value && x.speaker === speaker)) continue;
      pending.push({speaker, text:value});
      status.textContent = speaker ? `${speaker} konuşuyor • altyazı alınıyor…` : `${languageName()} altyazılar alınıyor…`;
    }
    if (pending.length && !processing && (pending.map(x => x.text).join(' ').length >= 160 || Date.now()-lastFlush >= 5500 || pending.some(x => x.speaker !== pending[0].speaker))) flush();
    // Detached caption nodes should not accumulate forever.
    if (seen.size > 200) for (const node of seen.keys()) if (!node.isConnected) seen.delete(node);
  }
  async function flush() {
    if (processing || paused || !pending.length) return;
    processing = true;
    // One request / card per speaker: never attribute another person's speech to them.
    const speaker = pending[0].speaker;
    const parts = [];
    while (pending.length && pending[0].speaker === speaker && parts.length < 12) {
      const next = pending[0].text;
      if (parts.length && parts.join(' ').length + next.length > 2600) break;
      parts.push(pending.shift().text);
    }
    const chunk = parts.join(' ').slice(0,2600);
    const mode=meetingLanguage;
    const recordMeetingId=meetingId;
    const record = {id:crypto.randomUUID(), at:archiveTime(), speaker, original:chunk, explanation:'', error:'', replies:[]};
    await archive(record,recordMeetingId,mode);
    lastFlush = Date.now();
    if(mode==='tr'){
      // Only capture and store original Turkish captions. No EXPLAIN message or OpenAI request.
      makeItem(speaker,chunk,'',false,[],'tr');
      status.textContent='Türkçe döküm kaydedildi • altyazı bekleniyor';
      processing=false;
      if(!paused && pending.length) flush();
      return;
    }
    status.textContent = 'Türkçe açıklama hazırlanıyor…';
    try {
      const response = await chrome.runtime.sendMessage({type:'EXPLAIN', text:chunk, speaker});
      if (response?.error) throw new Error(response.error);
      makeItem(speaker, chunk, response.explanation, false, response.replies, mode);
      await archive({...record, explanation:response.explanation, replies:response.replies || []},recordMeetingId,mode);
      status.textContent = 'Canlı dinlemede • altyazı bekleniyor';
    } catch(e) {
      makeItem(speaker, chunk, e.message || 'Açıklama alınamadı.', true, [], mode);
      await archive({...record, error:e.message || 'Açıklama alınamadı.'},recordMeetingId,mode);
      status.textContent = 'Hata • Ayarları kontrol et';
    } finally {
      processing = false;
      if (!paused && pending.length) flush();
    }
  }
  const timer = setInterval(collect,650);
  $('tta-history').addEventListener('click', () => chrome.runtime.sendMessage({type:'OPEN_ARCHIVE'}));
  $('tta-new').addEventListener('click', async () => {if (pending.length && !processing) await flush(); meetingId = crypto.randomUUID(); chrome.runtime.sendMessage({type:'CLEAR_CONTEXT'}); status.textContent='Yeni toplantı kaydı başlatıldı';});
  $('tta-toggle').addEventListener('click', () => {root.classList.toggle('tta-collapsed'); $('tta-toggle').textContent=root.classList.contains('tta-collapsed')?'+':'−';});
  $('tta-pause').addEventListener('click', () => {paused=!paused; $('tta-pause').textContent=paused?'Devam et':'Duraklat'; status.textContent=paused?'Duraklatıldı':'Altyazılar bekleniyor…'; if (!paused && pending.length) flush();});
  let drag=null;
  root.querySelector('.tta-top').addEventListener('pointerdown', e => {if(e.target.closest('button'))return;drag={x:e.clientX,y:e.clientY,left:root.getBoundingClientRect().left,top:root.getBoundingClientRect().top};root.querySelector('.tta-top').setPointerCapture(e.pointerId);});
  root.querySelector('.tta-top').addEventListener('pointermove', e => {if(!drag)return;root.style.left=Math.max(0,Math.min(window.innerWidth-root.offsetWidth,drag.left+e.clientX-drag.x))+'px';root.style.top=Math.max(0,Math.min(window.innerHeight-48,drag.top+e.clientY-drag.y))+'px';root.style.right='auto';});
  root.querySelector('.tta-top').addEventListener('pointerup', () => drag=null);
  document.addEventListener('visibilitychange', () => {if (document.visibilityState === 'hidden' && pending.length && !processing) flush();});
  window.addEventListener('pagehide', () => {clearInterval(timer); if (pending.length && !processing) flush();},{once:true});
})();
