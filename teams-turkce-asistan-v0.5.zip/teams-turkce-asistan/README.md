# Teams Türkçe Asistan v0.5

## Toplantı dili
- **Türkçe:** Sadece Teams canlı altyazılarını konuşmacı ve zaman bilgisiyle yerel arşive kaydeder. API anahtarı gerekmez ve OpenAI isteği yapılmaz. Teams içinde canlı altyazıların açık olması gerekir.
- **İngilizce:** OpenAI API anahtarı zorunludur. İngilizce altyazılara Türkçe açıklama ve uygun İngilizce cevap önerileri ekler; hepsini arşivler.

## Kurulum
1. ZIP içindeki dosyaları önceki eklenti klasörüne çıkarın (aynı klasörü kullanırsanız eski kayıtlar korunur).
2. `chrome://extensions` sayfasından eklentiyi yeniden yükleyin.
3. Eklenti simgesinden **Toplantı dili** seçip kaydedin; Teams'te de canlı altyazı dilini aynı dilde açın.
4. Toplantı arşivini **Toplantı geçmişi** üzerinden açın ve TXT/JSON indirin.

## Notlar
- Ses veya görüntü kaydetmez, Teams'in ekranda gösterdiği **canlı altyazı metnini** kaydeder.
- Teams DOM yapısı değişirse altyazı/konuşmacı algılaması ayarlanmalıdır. Bazı konuşmalar altyazıda eksik olabilir.
- Dil değiştirince aynı sayfada yeni toplantı arşivi başlatılır. Mevcut açık kaydın dilini değiştirmez.
- Arşiv Chrome eklentisinin yerel depolama alanındadır; tarayıcı verileri/eklenti silinirse kaybolabilir. Yedek için TXT/JSON dışa aktarın.
- İngilizce modunda veriler OpenAI API'ye gönderilir. Toplantı katılımcılarının gizlilik ve kurum politikalarını dikkate alın.
